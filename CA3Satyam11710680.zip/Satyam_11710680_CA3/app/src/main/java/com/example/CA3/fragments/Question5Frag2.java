package com.example.CA3.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.CA3.R;

public class Question5Frag2 extends Fragment {

    static TextView frag2Text;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View v =  inflater.inflate(R.layout.fragment_quest5_frag2, container, false);
        frag2Text = v.findViewById(R.id.frag2Text);

        return v;
    }

    public static void updateText(String a)
    {
        frag2Text.setText(a);
    }
}
