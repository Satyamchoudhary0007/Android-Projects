package com.example.CA3;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import static android.content.Context.MODE_PRIVATE;

@SuppressWarnings("deprecation")
public class MainFragment extends Fragment
{
    RadioButton red,green,blue,black,lime,pink,brown,yellow,orange,silver;
    SharedPreferences Shared;
    SharedPreferences.Editor editor;
    String color ="0";
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_main, container, false);
        red=view.findViewById(R.id.red);
        yellow=view.findViewById(R.id.yellow);
        orange=view.findViewById(R.id.orange);
        black=view.findViewById(R.id.black);
        blue=view.findViewById(R.id.blue);
        lime=view.findViewById(R.id.lime);
        pink=view.findViewById(R.id.pink);
        brown=view.findViewById(R.id.brown);
        green=view.findViewById(R.id.green);
        silver=view.findViewById(R.id.silver);

        Shared=this.getActivity().getSharedPreferences("myShared",MODE_PRIVATE);
        editor=Shared.edit();
        red.setChecked(true);
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color ="0";
                blue.setChecked(false);
                green.setChecked(false);
                yellow.setChecked(false);
                lime.setChecked(false);
                orange.setChecked(false);
                pink.setChecked(false);
                silver.setChecked(false);
                brown.setChecked(false);
                black.setChecked(false);
            }
        });
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color ="1";
                red.setChecked(false);
                green.setChecked(false);
                yellow.setChecked(false);
                lime.setChecked(false);
                orange.setChecked(false);
                pink.setChecked(false);
                silver.setChecked(false);
                brown.setChecked(false);
                black.setChecked(false);
            }
        });
        black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color ="2";
                blue.setChecked(false);
                green.setChecked(false);
                yellow.setChecked(false);
                lime.setChecked(false);
                orange.setChecked(false);
                pink.setChecked(false);
                silver.setChecked(false);
                brown.setChecked(false);
                red.setChecked(false);
            }
        });
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color ="3";
                blue.setChecked(false);
                red.setChecked(false);
                yellow.setChecked(false);
                lime.setChecked(false);
                orange.setChecked(false);
                pink.setChecked(false);
                silver.setChecked(false);
                brown.setChecked(false);
                black.setChecked(false);
            }
        });
        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color ="4";
                blue.setChecked(false);
                green.setChecked(false);
                red.setChecked(false);
                lime.setChecked(false);
                orange.setChecked(false);
                pink.setChecked(false);
                silver.setChecked(false);
                brown.setChecked(false);
                black.setChecked(false);
            }
        });
        brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color ="5";
                blue.setChecked(false);
                green.setChecked(false);
                yellow.setChecked(false);
                lime.setChecked(false);
                orange.setChecked(false);
                pink.setChecked(false);
                silver.setChecked(false);
                red.setChecked(false);
                black.setChecked(false);
            }
        });
        lime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color ="6";
                blue.setChecked(false);
                green.setChecked(false);
                yellow.setChecked(false);
                red.setChecked(false);
                orange.setChecked(false);
                pink.setChecked(false);
                silver.setChecked(false);
                brown.setChecked(false);
                black.setChecked(false);
            }
        });
        pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color ="7";
                blue.setChecked(false);
                green.setChecked(false);
                yellow.setChecked(false);
                lime.setChecked(false);
                orange.setChecked(false);
                red.setChecked(false);
                silver.setChecked(false);
                brown.setChecked(false);
                black.setChecked(false);
            }
        });
        silver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color ="8";
                blue.setChecked(false);
                green.setChecked(false);
                yellow.setChecked(false);
                lime.setChecked(false);
                orange.setChecked(false);
                pink.setChecked(false);
                red.setChecked(false);
                brown.setChecked(false);
                black.setChecked(false);
            }
        });
        orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color ="9";
                blue.setChecked(false);
                green.setChecked(false);
                yellow.setChecked(false);
                lime.setChecked(false);
                red.setChecked(false);
                pink.setChecked(false);
                silver.setChecked(false);
                brown.setChecked(false);
                black.setChecked(false);
            }
        });
        editor.putString("Name", color);
        editor.commit();

        return view;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {

        }
        else
        {
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
    }

}
