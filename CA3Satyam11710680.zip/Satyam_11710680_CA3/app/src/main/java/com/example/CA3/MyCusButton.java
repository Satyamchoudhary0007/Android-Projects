package com.example.CA3;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatButton;

import static android.content.ContentValues.TAG;

public class MyCusButton extends AppCompatButton {

    Context context;

    public MyCusButton(Context context) {
        super(context);
        init(context);
    }

    public MyCusButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public void init(final Context ct){
        this.context = ct;
        setOnHoverListener(new OnHoverListener() {
            @Override
            public boolean onHover(View view, MotionEvent motionEvent) {
                Log.d(TAG, "onHover: It's HOVERING");
                Toast.makeText(ct, "Hover", Toast.LENGTH_SHORT).show();
                switch (motionEvent.getAction()){
                    case MotionEvent.ACTION_HOVER_ENTER:
                        Log.d(TAG, "onHover: hover ACTION_ENTER");
                        break;
                    case MotionEvent.ACTION_HOVER_EXIT:
                        Log.d(TAG, "onHover: hover ACTION_EXIT");
                        break;
                }
                return false;
            }
        });
    }
}
