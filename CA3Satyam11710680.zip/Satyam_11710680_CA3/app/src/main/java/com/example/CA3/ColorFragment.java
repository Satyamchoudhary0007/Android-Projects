package com.example.CA3;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import static android.content.Context.MODE_PRIVATE;

@SuppressWarnings("ALL")
public class ColorFragment extends Fragment
{
    LinearLayout LinearColor;
    String string;
    SharedPreferences sharedPreferences;
    int i=0;
    int aa[]={R.color.RED,R.color.Blue,R.color.Black,R.color.Green,R.color.Yellow,R.color.Brown,R.color.Lime,R.color.Pink,R.color.Silver,R.color.Orange};
    @SuppressLint("ResourceAsColor")


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view1=inflater.inflate(R.layout.fragment_color, container, false);
        LinearColor=view1.findViewById(R.id.LinearColor);
        string =null;
        sharedPreferences =this.getActivity().getSharedPreferences("myShared",MODE_PRIVATE);
        string = sharedPreferences.getString("Name","0");
        i = Integer.parseInt(string.trim());

        LinearColor.setBackgroundResource(aa[i]);
        return view1;
    }
    public void onResume() {
        Toast.makeText(this.getActivity(),"Color Changed Succesfully!!", Toast.LENGTH_SHORT).show();
        super.onResume();
    }
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        }
        else
        {

        }
    }

    @Override
    public void onPause() {

        super.onPause();
    }
}
