package com.example.CA3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;

import com.example.CA3.fragments.Quset5Fragment1;
import com.example.CA3.fragments.Question5Frag2;

public class Question5 extends AppCompatActivity implements Quset5Fragment1.Send {

    Fragment frag2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question5);

        frag2 = new Question5Frag2();
    }

    @Override
    public void onSend(String a) {
        Question5Frag2.updateText(a);
    }
}
